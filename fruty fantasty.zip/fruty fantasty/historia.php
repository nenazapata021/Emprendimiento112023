<section id="historia">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Antecedentes históricos</h2>
                    <h3 class="section-subheading text-muted">
                    Las frutas provienen de diferentes tipos de plantas. Algunas frutas, como el plátano, la cereza y la manzana 
                    crecen en árboles. Otras frutas, como la fresa, la uva y la sandía crecen en vides. Frutas como el arándano y 
                    la frambuesa crecen en arbustos.</h3>
                </div>
            </div>
            <div class="row top-margin-md">
                <div class="col-md-6">
                    <a href="https://dribbble.com/shots/819957-Imac-psd"><img src="img/cole 3.jpg" class="img-responsive" alt=""></a>
                </div>
                <div class="col-md-6">
                    <h2><p class="before-header top-margin-lg">Institución Educativa Fe y Alegria Aures</p></h2>
                    <h1 class="section-heading">Acompañado por los profesores:<br>
                    Juan Carlos Perez<br>
                    Benhur Gutierrez</h1>
                    <h3 class="section-subheading text-muted bottom-margin-sm">Realizado por las alumnas:<br>
                    Yurley Salas Durango<br>
                    Edna Castañeda Zapata
                    <img src="img/escudo.png" class="img-responsive" alt="">
                    </h3>
                    <a href="#" class="btn btn-xl"></a>
                </div>
            </div>

                <div class="col-md-6">
                    <a href="https://dribbble.com/shots/1317713-iPad-Air-Template"><img src="img/portfolio/08.png" class="img-responsive" alt=""></a>
                </div>
            </div>
        </div>
    </section>


    <!-- Team Section -->
    <section id="clients" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading"></h2>
                    <h3 class="section-subheading text-muted"></h3>
                    <img src="img/pinchos.jpeg" alt="">
                </div>
            </div>

             <div class="row">
                <div class="col-md-3 col-sm-6">
                    <a target="_blank" href="http://cgi.tutsplus.com/">
                        <img src="img/logos/aetuts.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a target="_blank" href="http://designmodo.com/">
                        <img src="img/logos/designmodo.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                    <a target="_blank" href="https://wordpress.org/">
                        <img src="img/logos/wordpress.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
                <div class="col-md-3 col-sm-6">
                  
                    <a target="_blank" href="https://creativemarket.com">
                        <img src="img/logos/creative-market.jpg" class="img-responsive img-centered" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>