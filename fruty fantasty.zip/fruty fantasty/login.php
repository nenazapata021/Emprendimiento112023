<form action="index.php" method="post" class="form-control">
<div class="text-center mt-5">
                <h1>Ingreso al sistema</h1>
                <input type="text" name="user" placeholder="User name" class="form-control">
                <input type="password" name="pwd" placeholder="Passwors user" class="form-control">
                <button type="submit" value="ingreso" class="btn btn-outline-info">Ingreso</button>
                <button type="reset" value="cancelar" class="btn btn-outline-info">Cancelar</button>
</div>
</form>