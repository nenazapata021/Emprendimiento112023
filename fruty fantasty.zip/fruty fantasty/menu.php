<nav class="navbar navbar-expand-lg navbar-white bg-white">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" 
                data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">
               <?   if(isset($_SESSION["usuario_valido"])){
                  echo"Bienvenido ".$_SESSION["usuario_valido"];
                  }
                       ?>
                 </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                <ul class="navbar-nav">
                    <li class="hidden">
                        <a href="#page-top">Home</a>
                    </li>
                    <li class="nav-item">
                        <a  class="nav-link" href="#about"><h3>Acerca</h3></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#productos"><h3>Productos</h3></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#historia"><h3>Antecedentes</h3></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#clients"><h3>Clientes</h3></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#registro"><h3>Contacto</h3></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_usuarios.php"><h3>Admin:Usuarios</h3></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_productos.php"> 
                    <h3>Admin:Productos</h3>
                        </a>
                      <a class="nav-link" href="Manual de usuario.pptx"> 
                      <h3>Manual</h3>
                          </a>
                    </li>
                   <?   if(isset($_SESSION["usuario_valido"])){ ?>
                 
                  
                       
                  <li class="nav-item">
                        <a class="nav-link" href="salir.php">
                          <h3>Salir</h3>
                           <a class="nav-link" href="lista.php"> 
                    <h3>Pedido</h3>
                        </a>
                    </li>
                  <?}?>
                </ul>
               <?   if(!isset($_SESSION["usuario_valido"])){
                 
                       ?>
           <div class="form-group">   
              <form method="post" action="index.php">
      <input type="text" placeholder="Usuario" name="user" class="form-control">
                <input type="password" placeholder="Clave" name="pwd" class="form-control"><button type="submit" class="btn ">Enviar</button>
      </form>
           </div>
              <?}?>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
      
    </nav>
