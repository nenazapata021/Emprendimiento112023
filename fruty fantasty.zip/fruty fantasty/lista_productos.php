<?
session_start();
include 'head.php';
?>
<section class="page-sectio" id="lista_productos">
<div class="container">
<center><a href="index.php"><img src="img/house.png"></a></center>
<div class="row">
<div class="col-md">
    <img src="img/copas.png">
</div>
<div class="col-md">
<table class="table table-hover">
    <tr>
        <th>id</th>
        <th>Nombre</th>
        <th>Precio</th>
        <th>Editar</th>
        <th>Borrar</th>
    </tr>
    <?
    //if(isset($_SESSION['usuario_valido'])){
    include 'config/conexion.php';
     $sql="SELECT * FROM tblproductos order by id";
     $reg=mysqli_query($con,$sql) or die("Error to list user");
     while($r=mysqli_fetch_array($reg)){
        echo '<tr><td>'.$r["id"].'</td><td>'.$r["nombre"].'</td><td>'.$r["precio"].'</td>
      <td><a href=editar_producto.php?id='.$r["id"].'><img src="img/edit.png"></a></td>
      <td><a href=borrar_producto.php?id='.$r["id"].'><img src="img/delete.png"></a></td></tr>';
        }
     mysqli_close($con);
     echo'</table>';
    //}else{
       //header('Location:index.php'); 
    //}
    ?>
</div>
</div>
</div>
</section>