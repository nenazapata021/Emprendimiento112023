<?
session_start();
session_destroy();
print("<br><br><p class='btn btn-info btn-xl'>Session finalizada</p>");
//print("<meta http-equiv='refresh' contente='0;url=index.php'></meta>");
?>