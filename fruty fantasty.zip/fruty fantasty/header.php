<header>
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in"></div>
                <div class="intro-heading"></div>
                <a href="#about" class="page-scroll btn btn-xl">Ver más</a>
            </div>
        </div>
    </header>