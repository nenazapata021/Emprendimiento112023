<?
 session_start();
 include 'head.php';
 $id=$_REQUEST['id'];
 $perfil=$_REQUEST['perfil'];
 $id=trim($id);
?>
<div class="container">
    <div class="from-group">
        <?
         include 'config/conexion.php';
         $sql='UPDATE tblproductos set perfil=".$perfil." WHERE id=".$id."';
         $consulta=mysqli_query($con, $sql) or die("<div class='alert alert-success'>Error</div>");
         echo '<div class="alert alert-success">Producto Modificador</div>';
         header('Location:lista_productos.php');
        ?>
    </div>
</div>
