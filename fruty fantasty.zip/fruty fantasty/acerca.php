<section id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="section-heading">Acerca</h2>
                </div>
                <div class="col-md-6">
                    <p class="p-about">Nuestro proyecto se basa en la salud de las personas
                    y les agarren gusto a las frutas.
                    </p>
                    <img src="img/fruta.jpeg" class="img-responsive" width="60%" height="60%">
                     <p class="p-about">Resultado de la muestra del emprendimiento es:<br>
                      Un 97.3% de las personas  evaluaron como un producto excelente <br>
                       Un 2.7% de las personas calificaron como un producto bueno
                      <br> Un total 113 personas que visitaron y compraron nuestros productos.
                    </p>
                  <img src="img/medalla.jpeg" class="img-responsive" width="30%" height="30%">
                </div>
            </div>
        </div>
    </section>