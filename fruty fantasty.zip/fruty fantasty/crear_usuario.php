<section id="registro">
<div class="container pt-3">
   <div class="row"> 
    <div class="col-sm-4">
<img src="img/pincho 2.jpeg">
    </div>
  <div class="col-sm-6">
 <form method="post" action="genera_clave.php">
   
   <h1>Registrarse</h1>
 <div class="form-group">
 <label for="correo" class="lead">Correo:</label>
 <input type="email"
 class="form-control"
 id="correo"
 placeholder="Correo" name="correo" required> </div>
 <div class="form-group">
 <label for="nombre" class="lead">Nombre completo:</label>
 <input type="nombre"
 class="form-control" id="nombre"
 placeholder="Nombre" name="nombre" required>
 </div>
 <div class="form-group">
 <label for="pwd" class="lead">Contraseña:</label>
 <input type="password" class="form-control" id="pwd"
 placeholder="Enter password" name="pwd" required>
 </div>
 <div class="form-group">
 <label for="rpwd" class="lead">Confirmar contraseña:</label>
 <input type="password" class="form-control" id="rpwd"
 placeholder="Enter password" name="rpwd" required>
 </div>
 <button type="submit" class="btn btn-primary">Enviar
 </button>
 </form>
  </div>
   </div>
</div>
</section>