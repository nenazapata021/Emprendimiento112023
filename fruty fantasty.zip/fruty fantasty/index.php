<?
session_start();
if(isset($_REQUEST['user'])&& isset($_REQUEST['pwd'])){
$usuario=$_REQUEST['user'];
$clave=$_REQUEST['pwd'];
}
$clave_crypt="";
$nfilas=0;
if(isset($usuario) && isset($clave)){
include 'config/conexion.php';
$salt=substr($usuario,0,2);
$salt=strtoupper($salt);
$clave_crypt=crypt($clave,$salt);
$sql="SELECT nombre, clave, perfil FROM tblusuario WHERE nombre = '$usuario' AND clave = '$clave_crypt'";
$consulta=mysqli_query($con, $sql);
$nfilas=mysqli_num_rows($consulta);
while($reg=mysqli_fetch_array($consulta)){
  $_SESSION["usuario_valido"]=$reg['nombre'];
  $_SESSION["perfil"]=$reg['perfil'];

}//fin while
mysqli_close($con);
}//fin si hay usuario y clave
if($nfilas>0){
  $usuario_valido=$usuario;
  $_SESSION['usuario_valido']=$usuario_valido;
}
?>

<!DOCTYPE html>
<html lang="en">

<?
include 'head.php';
?>

<body id="page-top" class="index">
    <?
    include 'menu.php';
    ?>
    <!-- Header -->
    <?
    include 'header.php'
    ?>
    <!-- Services Section -->
    <?
    include 'acerca.php';
    ?>
    <!-- Portfolio Grid Section -->
   <?include 'productos.php'?>

    <!-- About Section -->
  <?include 'historia.php'?>
    <!-- Contact Section -->
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading"></h2>
                    <h3 class="section-subheading text-muted bottom-margin-sm"></h3>
                    
                    <a target="_blank" href="mailto:contact@creative.com" class="btn btn-xl"></a>
                </div>
            </div>
           
        
        </div>
    </section>
    <?include 'crear_usuario.php'?>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                  Colocar información del contacto
                   </div>
                <div class="col-md-4">
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">
            Colocar creditos y recursos
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- Portfolio Modals -->
    <!-- Use the modals below to showcase details about your portfolio projects! -->

    <!-- Portfolio Modal 1 -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                        <img src="img/fresa-masmelo.jpeg" class="img-responsive" alt="">
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="https://www.behance.net/gallery/37627001/iPhone-6s-Space-Gray-mockups-FREEBIE">Mockup</a></p>
                                <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://360mockups.com/">360 Mockups</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 2 -->
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <h2>Project Heading</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/02x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                               <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="http://freebiesbug.com/psd-freebies/app-showcase-mockup-psd/">Mockup</a></p>
                               <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="https://dribbble.com/ikima">Vitaly</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 3 -->
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/03x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="https://creativemarket.com/muwa_one/707383-Workspace-Mockup-Set-5">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="https://creativemarket.com/muwa_one">Best Pixels</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 4 -->
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/04x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="https://dribbble.com/shots/1998349-Ceramic-Bottle-Mockup-Free-PSD">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://graphicburger.com/">Raul Taciu</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 5 -->
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/05x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="http://graphicburger.com/street-billboard-psd-mockup-2/">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://graphicburger.com/">Graphic Burger</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 6 -->
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/06x.jpg" alt="">
                               <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="http://graphicburger.com/paper-pouch-packaging-mockup/">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://graphicburger.com/">Graphic Burger</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/agency.min.js"></script>

</body>

</html>
