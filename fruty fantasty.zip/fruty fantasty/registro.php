<!DOCTYPE html>
<html lang="en">

<?
include 'head.php';
?>

<body id="page-top" class="index">
  
    <?include 'menuadmin.php'?>
    <?
    include 'menu.php';
    ?>
    <!-- Header -->
    <?
    include 'header.php'
    ?>
    <!-- Services Section -->
    <?
    include 'acerca.php';
    ?>
    <?include 'login.php'?>

    <!-- Portfolio Grid Section -->
    <section id="portafolio" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Portafolio</h2>
                    <h3 class="section-subheading text-muted">Nuestro proyecto se basa en la salud de las personas
                    y les agarren gusto a las frutas.</h3>
                    <img src="img/fresa-masmelo.jpeg" class="img-responsive" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal1" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/fresa-masmelo.jpeg" class="img-responsive" alt="">
                 
                    </a>
                    <div class="portfolio-caption">
                        <h4>Corporate X</h4>
                        <p class="text-muted">Mobile Web Design</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                <img src="img/fruty 3.png" class="img-responsive" alt="">

                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                <img src="img/fruty 4.png" class="img-responsive" alt="">

                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Servicios</h2>
                    <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec egestas dignissim ullamcorper.<br>Sed ut orci rutrum, bibendum nisl a, bibendum massa.</h3>
                </div>
            </div>
            <div class="row top-margin-md">
                <div class="col-md-6">
                    <a href="https://dribbble.com/shots/819957-Imac-psd"></a>
                </div>
                <div class="col-md-6">
                    <p class="before-header top-margin-lg">incredible websites</p>
                    <h2 class="section-heading">website development</h2>
                    <h3 class="section-subheading text-muted bottom-margin-sm">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec egestas dignissim ullamcorper. Sed ut orci rutrum, bibendum nisl a, bibendum massa. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec egestas dignissim ullamcorper. Sed ut orci rutrum, bibendum nisl a, bibendum massa.</h3>
                    <a href="#" class="btn btn-xl">Learn More</a>
                </div>
            </div>

            <div class="row top-margin-lg hidden-sm hidden-xs">
                <div class="col-md-6">
                    <p class="before-header top-margin-lg">incredible websites</p>
                    <h2 class="section-heading">Mobile Design</h2>
                    <h3 class="section-subheading text-muted bottom-margin-sm">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec egestas dignissim ullamcorper. Sed ut orci rutrum, bibendum nisl a, bibendum massa. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec egestas dignissim ullamcorper. Sed ut orci rutrum, bibendum nisl a, bibendum massa.</h3>
                    <a href="#" class="btn btn-xl">Learn More</a>
                </div>
                <div class="col-md-6">
                    <a href="https://dribbble.com/shots/1317713-iPad-Air-Template"><img src="img/portfolio/08.png" class="img-responsive" alt=""></a>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section id="clients" class="bg-light-gray">
        <div class="container">
            <div class="row">
              
                <div class="col-lg-12 text-center">
                    
                    <h3 class="section-subheading text-muted">
                       <img src="img/pinchos.jpeg" class="img-responsive" width="40%" height="80%">
                    </h3>
                </div>
            </div>
          </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Contact Us</h2>
                    <h3 class="section-subheading text-muted bottom-margin-sm">Lorem ipsum dolor sit amet consectetur.</h3>
                    <a target="_blank" href="mailto:contact@creative.com" class="btn btn-xl">contact@creative.com</a>
                </div>
            </div>
           
        
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <span class="copyright">For more information visit: <a href="http://templune.com">http://templune.com</a></span>
                </div>
                <div class="col-md-4">
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">
                        <li><a href="http://templune.com/plantilla-de-bootstrap-gratis.html">Credits and Resources</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- Portfolio Modals -->
    <!-- Use the modals below to showcase details about your portfolio projects! -->

    <!-- Portfolio Modal 1 -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/01x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="https://www.behance.net/gallery/37627001/iPhone-6s-Space-Gray-mockups-FREEBIE">Mockup</a></p>
                                <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://360mockups.com/">360 Mockups</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 2 -->
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <h2>Project Heading</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/02x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                               <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="http://freebiesbug.com/psd-freebies/app-showcase-mockup-psd/">Mockup</a></p>
                               <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="https://dribbble.com/ikima">Vitaly</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 3 -->
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/03x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="https://creativemarket.com/muwa_one/707383-Workspace-Mockup-Set-5">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="https://creativemarket.com/muwa_one">Best Pixels</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 4 -->
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/04x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="https://dribbble.com/shots/1998349-Ceramic-Bottle-Mockup-Free-PSD">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://graphicburger.com/">Raul Taciu</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 5 -->
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/05x.jpg" alt="">
                                <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="http://graphicburger.com/street-billboard-psd-mockup-2/">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://graphicburger.com/">Graphic Burger</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Portfolio Modal 6 -->
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="modal-body">
                                <!-- Project Details Go Here -->
                                <h2>Project Name</h2>
                                <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                                <img class="img-responsive img-centered" src="img/portfolio/06x.jpg" alt="">
                               <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                                <p><strong>You can download this PSD Mockup template in this portfolio sample item at</strong> <a target="_blank" href="http://graphicburger.com/paper-pouch-packaging-mockup/">Mockup</a></p>
                                 <ul class="list-inline">
                                    <li>Date: July 2016</li>
                                    <li><b>Author:</b> <a target="_blank" href="http://graphicburger.com/">Graphic Burger</a></li>
                                    <li>Category: Graphic Design</li>
                                </ul>
                                <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/agency.min.js"></script>

</body>

</html>
