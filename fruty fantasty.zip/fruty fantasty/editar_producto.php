<?
include 'head.php';
$idusuario=$_REQUEST['id'];
$correo="";
$usuario="";
$perfil=0;
$nperfil=""; 
include 'config/conexion.php';
 $instruccion = "SELECT * FROM tblproductos WHERE id='$idusuario'";
 $consulta = mysqli_query ($con, $instruccion) 
 or die ("Fallo en la consultar Usuario"); 
 while($reg=mysqli_fetch_array($consulta)){
       $producto=$reg['nombre'];
       $precio=$reg['precio'];
 }
 mysqli_close($con);
 if($perfil==0){
  $nperfil="Bloqueado";
 }
 if($perfil==1){
  $nperfil="Desbloqueado";
 }
?>
<div class="page-section" id="editar_producto">
<div class="container">
<a href="lista_productos.php"><img src="img/house.png"></a>
<form method="post" action="salvar_producto.php">
 <div class="form-group">
     <label for="id">ID</label>  
     <input type="text" name="id" value=<? echo $idusuario?> class="form-control" readonly>
 </div>
 <div class="form-group">
      <label for="usuario">USUARIO</label>  
      <input type="text" name="usuario" value=<? echo $usuario?>  class="form-control" readonly>
 </div>
 <div class="form-group">
      <label for="correo">CORREO</label>  
      <input type="text" name="usuario" value=<? echo $correo?>  class="form-control" readonly>
 </div>
 <div class="form-group">
    <label for="perfil" name="PERFIL"</label>  
    <select name="peril" class="form-control">
       <option value=<? echo $perfil?>>  <?echo $nperfil?></option>
       <option value="0">Bloqueado</option>
       <option value="1">Desbloqueado</option>
    </select>
    <div class="form-group">
      <button type="submit" class="btn btn-danger">Save</button>
    </div>
 </div>
</form>  
</div>
</div>