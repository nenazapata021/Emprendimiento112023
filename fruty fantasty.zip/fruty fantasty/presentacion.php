<div class="jumbutron text-center">
    <h1>Bienvenid@</h1>
    <p>Session Iniciada</p>
    <?
    echo'<br>'.$_SESSION['usuario_valido'];
    echo'<br>Perfil : '.$_SESSION['perfil'];
    ?>
</div>